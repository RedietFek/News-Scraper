<template>
<div class="container">
    <h3>News is page which contains the most important of such news and carries them to the people in general. It may be called a summary of the important current events. News is very important in the life of a civilized nation. It is the medium through which public opinion is expressed <br> the most important news both here and abroad. It is usually found on the front page of the news. The title of the most important news is written in big bold letters. It is called banner headline. ... Sports Page- This page contains news about sports events in and out of the country</h3>
</div>
</template>
