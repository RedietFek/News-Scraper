<template>
  <footer>
      <div class="text-center">News App Project AAIT Loremdae ei</div>
    </footer>
</template>

<script>
export default {
  name: 'footer'
}
</script>

<style scoped>
footer {
  background: #343A40;
  padding: 11px;
  color: #fff;
  margin-top: 70px;
}
</style>
